from __future__ import annotations

from typing import Any, Dict, TYPE_CHECKING

import weaviate as WeaviateClient

from airflow.hooks.base import BaseHook


class WeaviateHook(BaseHook):
    """
    Hook that interacts with Weaviate Vector Database.

    :param method: the API method to be called
    :type method: str
    :param weaviate_conn_id: connection that has the weaviate host i.e http://weaviate:8081
        and optional authentication credentials and additional_headers
    :type weaviate_conn_id: str

    The connection string should use "extras" for the API Token as well as any 
    service api tokens (ie. OpenAI, Hugging Face, etc.).  Anything in "extras" will be populated as 
    "additional_headers" for the Weaviate client connection.

    If login or password are specified in the connection they will be used for OIDC client authentication.

    If a API token is specified it will take precedence over OIDC authentication. 

    For example:

    {
        "conn_type": "weaviate", 
        "host": "http://weaviate:8081", 
        "login": "mylogin",  ##OIDC login username
        "password": "mypw", ##OIDC login password
        "extra": {"token": "adminkey", 
                  "X-OpenAI-Api-Key": "sk-xxxxxxx",
                  "X-Huggingface-Api-Key": "aaaaaaaa"
                  }
    }
    """

    conn_name_attr = "weaviate_conn_id"
    default_conn_name = "weaviate_default"
    conn_type = "weaviate"
    hook_name = "Weaviate"

    @staticmethod
    def get_connection_form_widgets() -> dict[str, Any]:
        """Returns connection widgets to add to connection form"""
        from flask_appbuilder.fieldwidgets import BS3PasswordFieldWidget, BS3TextFieldWidget
        from flask_babel import lazy_gettext
        from wtforms import PasswordField, StringField

        return {
            "token": StringField(lazy_gettext("Weaviate API Token"), widget=BS3TextFieldWidget()),
            "X-OpenAI-Api-Key": StringField(lazy_gettext("OpenAI API Key"), widget=BS3TextFieldWidget()),  
            "X-Azure-Api-Key": StringField(lazy_gettext("Azure OpenAI API Key"), widget=BS3TextFieldWidget()), 
            "X-Huggingface-Api-Key": StringField(lazy_gettext("Hugging Face API Key"), widget=BS3TextFieldWidget()), 
            "X-Cohere-Api-Key": StringField(lazy_gettext("Cohere API Key"), widget=BS3TextFieldWidget()), 
            "X-Palm-Api-Key": StringField(lazy_gettext("PaLM API Key"), widget=BS3TextFieldWidget()),
        }

    @staticmethod
    def get_ui_field_behaviour() -> dict:
        """Returns custom field behaviour"""

        return {
            "hidden_fields": ["port", "schema"],
            "relabeling": {
                "login": "OIDC Username",
                "password": "OIDC Password",
            },
            "placeholders": {
                "X-OpenAI-Api-Key": "sk-xxxxxxxxxxxxxxxx",
                "X-Azure-Api-Key": "sk-xxxxxxxxxxxxxxxx",
                "host": "http://weaviate:8081",
            },
        }

    def __init__(
        self,
        weaviate_conn_id: str = default_conn_name,
    ) -> None:
        super().__init__()
        self.weaviate_conn_id = weaviate_conn_id

    def get_conn(self) -> WeaviateClient:
        """Function that initiates a new Weaviate connection with token and hostname."""

        conn = self.get_connection(self.weaviate_conn_id)
        url = conn.host
        username = conn.login or ''
        password = conn.password or ''
        extras = conn.extra_dejson
        token = extras.pop('token', '')
        additional_headers = extras.copy()
        scope = conn.extra_dejson.get('oidc_scope', 'offline_access')

        if token == '' and username != '':
            auth_client_secret = WeaviateClient.AuthClientPassword(username=username, password=password, scope=scope)
        else:
            auth_client_secret=WeaviateClient.AuthApiKey(token)

        self.client = WeaviateClient.Client(url=url, auth_client_secret=auth_client_secret, additional_headers=additional_headers)

        return self.client

    def run(
        self,
        query: str,
        **request_kwargs,
    ) -> Any | Dict[str, Any]:
        """
        Executes GraphQL query with the Weaviate connection

        ie. 
        {
            "query": "{ # GRAPHQL QUERY }"
        }

        :param query: The GraphQL query as JSON
        :type query: dict
        """
        self.get_conn()
        return_dict = self.client.query.raw(query)
        return return_dict

    def test_connection(self) -> tuple[bool, str]:
        """Test Weaviate connection."""
        self.get_conn()
        try:
            if TYPE_CHECKING:
                assert self.client
            if self.client.is_live():
                return True, "Successfully connected to Weaviate."
            else:
                return False, "Could not connect to Weaviate."
        except Exception as e:
            return False, str(e)
        
    def check_health(self, all_nodes:bool = False) -> str:
        self.get_conn()
        cluster_status = self.client.cluster.get_nodes_status()
        node_status = set([node['status'] for node in cluster_status])

        if all_nodes:
            if node_status == set(['HEALTHY']):
                return 'HEALTHY'
        elif 'HEALTHY' in node_status:
            return 'HEALTHY'
        
        return 'NOT HEALTHY'