from __future__ import annotations

from pathlib import Path

from airflow.exceptions import AirflowSkipException
from airflow.models.dagrun import DagRun
from airflow.utils import timezone
from airflow.utils.state import DagRunState, State
from airflow.utils.types import DagRunType
import pytest
from airflow.utils import timezone
from airflow.models.dagbag import DagBag
from airflow.utils.state import DagRunState, State
from airflow.models.dagrun import DagRun
from airflow.utils.db import create_default_connections
from airflow.utils.session import provide_session

@provide_session
def get_session(session=None):  # skipcq: PYL-W0621
    create_default_connections(session)
    return session

@pytest.fixture()
def session():
    return get_session()

dag_bag = DagBag(Path('__file__').parent.parent / "example_dags", include_examples=False)

@pytest.mark.parametrize("dag_id", dag_bag.dag_ids)
def test_example_dag(session, dag_id: str):  # skipcq: PYL-W0613, PYL-W0621
    dag = dag_bag.get_dag(dag_id)

    execution_date = None
    run_conf = None
    conn_file_path = None
    variable_file_path = None
    start_date = execution_date = timezone.utcnow()
    run_id=DagRun.generate_run_id(DagRunType.MANUAL, execution_date)

    dag.log.debug("Clearing existing task instances for execution date %s", execution_date)
    dag.clear(
        start_date=execution_date,
        end_date=execution_date,
        dag_run_state=False,  # type: ignore
        session=session,
    )
    
    dag.log.debug("Getting dagrun for dag %s", dag.dag_id)
    dr: DagRun = (
        session.query(DagRun)
        .filter(DagRun.dag_id == dag.dag_id, DagRun.execution_date == execution_date)
        .first()
    )
    if dr:
        session.delete(dr)
        session.commit()
    dr = dag.create_dagrun(
        state=DagRunState.RUNNING,
        execution_date=execution_date,
        run_id=run_id,
        start_date=start_date or execution_date,
        session=session,
        conf=run_conf,  # type: ignore
    )
    dag.log.info("created dagrun %s", str(dr))

    tasks = dag.task_dict

    dag.log.debug("starting dagrun")
    
    while dr.state == State.RUNNING:
        schedulable_tis, _ = dr.update_state(session=session)
        for ti in schedulable_tis:
            ti.start_date = timezone.utcnow()
            session.add(ti)
        session.flush()
        for ti in schedulable_tis:
            # add_logger_if_needed(dag, ti)
            ti.task = tasks[ti.task_id]

            dag.log.info("*****************************************************")
            if hasattr(ti, "map_index") and ti.map_index > 0:
                dag.log.info("Running task %s index %d", ti.task_id, ti.map_index)
            else:
                dag.log.info("Running task %s", ti.task_id)
            try:
                ti._run_raw_task(session=session)
                session.add(ti)
                session.flush()
                dag.log.info("%s ran successfully!", ti.task_id)
            except AirflowSkipException:
                dag.log.info("Task Skipped, continuing")
            dag.log.info("*****************************************************")


    return dr