import json
from pendulum import datetime
import numpy as np
import json
from pathlib import Path
import pandas as pd 
from weaviate.util import generate_uuid5

from airflow.decorators import dag, task
from weaviate_provider.operators.weaviate import WeaviateBackupOperator
from weaviate_provider.operators.weaviate import WeaviateImportDataOperator
from weaviate_provider.operators.weaviate import WeaviateRestoreOperator
from weaviate_provider.operators.weaviate import WeaviateCreateSchemaOperator
from weaviate_provider.operators.weaviate import WeaviateCheckSchemaOperator
from weaviate_provider.operators.weaviate import WeaviateCheckSchemaBranchOperator
from weaviate_provider.operators.weaviate import WeaviateRetrieveAllOperator

from weaviate_provider.hooks.weaviate import WeaviateHook

#assume these variables are set in docker-compose.override.yml
#setting here makes no difference, only for reference and interactive testing
# os.environ['AIRFLOW_CONN_WEAVIATE_ADMIN'] = json.dumps({"conn_type": "weaviate", 
#                                                           "host": "http://weaviate:8081", 
#                                                           "extra": {"token": "adminkey"}})
# os.environ['AIRFLOW_CONN_WEAVIATE_USER'] = json.dumps({"conn_type": "weaviate", 
#                                                           "host": "http://weaviate:8081", 
#                                                           "extra": {"token": "readonlykey"}})

_WEAVIATE_CONN_ID = 'weaviate_user'

@dag(schedule=None,
     start_date=datetime(2023, 4, 1),
     catchup=False,
     default_args={
         "weaviate_conn_id": _WEAVIATE_CONN_ID,
        #  "retries": 2,
         },
         tags=["weaviate"],
)
def weaviate_example():
    """
    ### Basic Weaviate DAG
    This DAG demonstrates the use of the Weaviate provider for simple operations of 
    loading, backing up and restoring data to a Weaviate vector database.

    The WeaviateHook can make connections using Anonymous, OIDC or API Key methods. 

    This demo will use both Anonymous and API key connections to a local weaviate 
    container by setting AIRFLOW_CONN_WEAVIATE_<> environment variables.

    Use the [Weaviate Console](https://link.weaviate.io/3pYv35u) to query
    """
    _create_schema = WeaviateCreateSchemaOperator(task_id='create_schema', 
                                                  weaviate_conn_id='weaviate_admin',
                                                  class_object_data='file://include/data/schema.json',
                                                  existing='replace',
                                                  )
        
    _check_schema = WeaviateCheckSchemaOperator(task_id='check_schema', 
                                                weaviate_conn_id='weaviate_admin',
                                                class_object_data=Path('include/data/schema.json').read_text(), 
                                                )
    
    #inject schema error
    new_schema = json.loads(Path('include/data/schema.json').read_text())
    new_schema['classes'][0]['class'] = 'bookERROR'
    
    _check_schema_branch = WeaviateCheckSchemaBranchOperator(task_id='check_schema_branch', 
                                                                weaviate_conn_id='weaviate_admin',
                                                                class_object_data=json.dumps(new_schema), 
                                                                follow_task_ids_if_true=["generate_book_embeddings", "generate_and_import"],
                                                                follow_task_ids_if_false=['_recreate_schema']
                                                    )
    
    _recreate_schema = WeaviateCreateSchemaOperator(task_id='_recreate_schema', 
                                                    weaviate_conn_id='weaviate_admin',
                                                    class_object_data='file://include/data/schema.json',
                                                    existing='replace',
                                                    trigger_rule='none_failed',
                                                   )

    @task.virtualenv(requirements='minio')
    def create_minio_buckets(bucket_names={'weaviate': 'weaviate-backup', 'data': 'weaviateprovidertest'}, 
                             replace_existing=True) -> dict:
        import minio
        from time import sleep

        minio_client = minio.Minio(
            endpoint='localhost:9000',
            access_key='minioadmin',
            secret_key='minioadmin',
            secure=False
        )

        for bucket_name in bucket_names.values():
            if replace_existing:
                try:
                    for object in minio_client.list_objects(bucket_name=bucket_name, recursive=True):
                        minio_client.remove_object(bucket_name=bucket_name, object_name=object.object_name)
                    minio_client.remove_bucket(bucket_name)
                except:
                    pass
            
            sleep(10)

            try:
                minio_client.make_bucket(bucket_name)
            except Exception as e:
                if e.code == 'BucketAlreadyOwnedByYou':
                    print(e.message)
        
        return bucket_names

    _create_minio_buckets = create_minio_buckets()

    @task(trigger_rule='none_failed')
    def generate_book_embeddings() -> str:
        """
        We may want to generate data for embedding and import as part of a
        separate task.  Here we generate the data and pass it as an argument
        to the WeaviateImportDataOperator downstream.
        """
        
        import pandas as pd
        from weaviate.util import generate_uuid5

        output_file = 'file://include/data/books_embeddings.parquet'

        df = pd.read_parquet('include/data/books.parquet')

        df['vector'] = np.full((len(df),5), .12345).tolist()

        #title is left off of identifier in order to generate different embeddings than from the decorator
        df['uuid'] = df.apply(lambda x: generate_uuid5(identifier=x[['author', 'description']].to_dict(),
                                                       namespace='Book'),
                                                    axis=1)

        df.to_parquet(output_file)

        return output_file
    
    @task.weaviate_import(weaviate_conn_id='weaviate_admin', trigger_rule='none_failed')
    def generate_and_import(class_name:str):
        """
        The decoperator provides the ability to run a python_callable function
        just prior to operator execution.  We can generate the pandas dataframe
        and return it as operator arguments to WeaviateImportOperator.
        """
        
        df = pd.read_parquet('include/data/books.parquet')

        df['vector'] = np.full((len(df),5), .12345).tolist()

        df['uuid'] = df.apply(lambda x: generate_uuid5(identifier=x[['author', 'title', 'description']].to_dict(),
                                                       namespace=class_name),
                                                    axis=1)
        return {"data":df, 
                "class_name":class_name, 
                "uuid_column": "uuid", 
                "embedding_column": "vector",
                "batch_size": 20,
                "error_threshold": 0,
            }
    
    @task.weaviate_import(weaviate_conn_id='weaviate_admin', trigger_rule='none_failed')
    def generate_and_upsert(class_name:str):
        """
        Change some of the import in order to test upsert.
        """
        
        df = pd.read_parquet('include/data/books.parquet')
        x = df.iloc[0]['author'] + ' UPSERT'
        df.iloc[0]['author'] = x

        df['vector'] = np.full((len(df),5), .12345).tolist()

        df['uuid'] = df.apply(lambda x: generate_uuid5(identifier=x[['author', 'title', 'description']].to_dict(),
                                                       namespace=class_name),
                                                    axis=1)
        
        return {"data":df, 
                "class_name":class_name, 
                "uuid_column": "uuid", 
                "embedding_column": "vector",
                "batched_mode": False,
                "existing": "skip",
                "upsert": True,
                "primary_key": "title",
                "error_threshold": 0,
            }
    
    _book_embeddings = generate_book_embeddings()
    
    _import_embedded_data = WeaviateImportDataOperator(task_id='import_embedded_data',
                                                       weaviate_conn_id='weaviate_admin',
                                                       data_file_path=_book_embeddings,
                                                       class_name='Book',
                                                       batched_mode=False,
                                                       batch_size=20,
                                                       embedding_column='vector',
                                                       uuid_column='uuid',
                                                       error_threshold=3,
                                                       )
    
    _backup = WeaviateBackupOperator(task_id='backup_fs', 
                                     weaviate_conn_id='weaviate_admin',
                                     backend='filesystem', 
                                     id="backup_fs_"+"{{ ts_nodash }}",
                                     include=['Book'],
                                     )
    
    _restore = WeaviateRestoreOperator(task_id='restore_fs',
                                       weaviate_conn_id='weaviate_admin',
                                       backend='filesystem', 
                                       id="backup_fs_"+"{{ ts_nodash }}",
                                       include=['Book'],
                                       replace_existing=True,
                                       )
    
    _backup_s3 = WeaviateBackupOperator(task_id='backup_s3', 
                                        weaviate_conn_id='weaviate_admin',
                                        backend='s3', 
                                        id="backup_s3_"+"{{ ts_nodash }}",
                                        include=['Book'],
                                        )
    
    _restore_s3 = WeaviateRestoreOperator(task_id='restore_s3',
                                          weaviate_conn_id='weaviate_admin',
                                          backend='s3', 
                                          id="backup_s3_"+"{{ ts_nodash }}",
                                          include=['Book'],
                                          replace_existing=True,
                                          )
    
    _retrieval_all = WeaviateRetrieveAllOperator(task_id='retrieve_all',
                                                 class_name='Book',
                                                 output_file='file://include/data/books_retrieved.parquet',
                                                 replace_existing=True,
                                                #  output_file='file://include/data/books_retrieved_'+"{{ ts_nodash }}"+'.parquet',
                                                 )
    
    @task()
    def check_embeddings_count():
        hook = WeaviateHook('weaviate_user')      

        query = '{ Aggregate { Book { meta { count } } } }'
        
        assert hook.run(query=query)['data']['Aggregate']['Book'][0]['meta']['count'] == 10

        assert hook.client.query.raw(query)['data']['Aggregate']['Book'][0]['meta']['count'] == 10

    _generate_and_import = generate_and_import(class_name='Book')
    _generate_and_upsert = generate_and_upsert(class_name='Book')

    _check_embedding_count = check_embeddings_count()

    _create_schema >> _check_schema >> _check_schema_branch >> [_recreate_schema, _book_embeddings, _generate_and_import]
    _recreate_schema >> [_book_embeddings, _generate_and_import]
    _book_embeddings >> _import_embedded_data >> _backup >> _restore >> _retrieval_all >> _check_embedding_count
    _generate_and_import >> _generate_and_upsert >> _backup_s3 >> _restore_s3 >> _retrieval_all >> _check_embedding_count
    _create_minio_buckets >> _backup_s3 

weaviate_example()